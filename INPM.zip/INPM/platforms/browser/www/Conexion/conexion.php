<?php
//Configuracion de la conexion a base de datos

if (!isset($_SESSION)) {
  session_start();
}

# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_himnario = "localhost";
$database_himnario = "himnario";
$username_himnario = "root";
$password_himnario = "";

$himnario = mysql_pconnect($hostname_himnario, $username_himnario, $password_himnario) or trigger_error(mysql_error(),E_USER_ERROR); 

?>